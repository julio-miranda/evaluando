//hecho por : Julio Armando Miranda Reyes
//carnet: MR18031
#include <cstdlib>
#include <iostream>
#include <windows.h>
#include <iomanip> 
#include <stdlib.h>
#include <conio.h>

using namespace std;

struct cliente{
	
	int nombre;
	int Apellido;
	int DUI;
	int licencia;
}cliente1;

void cl();
void sy();

int main(){
	//declaracion de variables necesarias
	int a;
	int Tiempo;
	int c;
	int m;
	int b;
	int A;
	int Costo;
	int Nombre;
	int Distancia;
	int e;

system("color 34");
	do{
	//ingreso de datos
	cout<<"\n--------------MENU------------------\n"<<endl;
	cout<<" "<<endl;
	cout<<"\na) Mostrar Vehiculos\n"<<endl;//es para mostrar los vehiculos
	cout<<"\nb) Agregar cliente Nuevo\n"<<endl;//es para agregar cliente nuevo
	cout<<"\nc) Agregar Vehiculo Nuevo\n"<<endl;//es para agregar informacion de un vehiculo nuevo
	cin>>a;
	cl();
	} while(a<1 || a>3);// inicio del ciclo while		
	
	//si eligen la opcio 1 y asi mostrar las opciones de vehiculos
	for(a=1; a<2; a++){
	cout<<"1- AUDI A4"<<endl;//es opcion 1 
	cout<<"2- ASTON MARTIN Vantage V8"<<endl;//es opcion 2
	cout<<"3- BENTLEY Continental GT"<<endl;//es opcion 3
	cout<<"4- BMW Serie 3"<<endl;//es opcion 4
	cout<<"5- CHEVROLET Cruze"<<endl;//es opcion 5
	cout<<"6- CITROEN C4"<<endl;//es opcion 6
	cin>>c;//ingreso de opciones
	cl();
}while(c<1 || c>6);
		//Los datos de la opcion 1 del menu de vehiculos 
		for(c=1; c<2; c++){
		cout<<"Modelo:"<<"2018 A4 Sedan"<<endl;
		cout<<" "<<endl;
				
		cout<<"distancia:"<<"2,000km"<<endl;
		cout<<" "<<endl;
		
		cout<<"por cuanto tiempo lo quiere:"<<endl;
		cin>>e;
		cout<<" "<<endl;
		
		cout<<"Precio:"<<e*32<<"$"<<endl;
		cout<<" "<<endl;
	}
		//Los datos de la opcion 2 del menu de vehiculos 
		for(c=2; c<3; c++){
		cout<<"Modelo:"<<"ASTON MARTIN Vantage V8"<<endl;
		cout<<" "<<endl;
		
		cout<<"distancia:"<<"1,000km"<<endl;
		cout<<" "<<endl;
		
		cout<<"por cuanto tiempo lo quiere:"<<endl;
		cin>>e;
		cout<<" "<<endl;
		
		cout<<"Precio:"<<e*20<<"$"<<endl;
		cout<<" "<<endl;
	}
	    //Los datos de la opcion 3 del menu de vehiculos 
		for(c=3; c<4; c++){
		cout<<"Modelo:"<<"BENTLEY Continental GT"<<endl;
		cout<<" "<<endl;
		
		cout<<"distancia:"<<"1,000km"<<endl;
		cout<<" "<<endl;
		
		cout<<"por cuanto tiempo lo quiere:"<<endl;
		cin>>e;
		cout<<" "<<endl;
		
		cout<<"Precio:"<<e*28<<"$"<<endl;
		cout<<" "<<endl;
	}
		//Los datos de la opcion 4 del menu de vehiculos 
		for(c=4; c<5; c++){
		system("cls");
		cout<<"Modelo:"<<"BMW Serie 3"<<endl;
		cout<<" "<<endl;
		
		cout<<"distancia:"<<"1,500km"<<endl;
		cout<<" "<<endl;
		
		cout<<"por cuanto tiempo lo quiere:"<<endl;
		cin>>e;
		cout<<" "<<endl;
		
		cout<<"Precio:"<<e*25<<"$"<<endl;
		cout<<" "<<endl;
	}
	    //Los datos de la opcion 5 del menu de vehiculos 
		for(c=5; c<6; c++){
		cout<<"Modelo:"<<"CHEVROLET Cruze"<<endl;
		cout<<" "<<endl;
		
		cout<<"por cuanto tiempo lo quiere:"<<endl;
		cin>>e;
		cout<<" "<<endl;
		
		cout<<"Precio:"<<e*25<<"$"<<endl;
		cout<<" "<<endl;
		
		cout<<"distancia:"<<"1,700km"<<endl;
		cout<<" "<<endl;
	}
		//Los datos de la opcion 6 del menu de vehiculos 
		for(c=6; c<7; c++){
		cout<<"Modelo:"<<"CITROEN C4"<<endl;
		cout<<" "<<endl;
		
		cout<<"por cuanto tiempo lo quiere:"<<endl;
		cin>>e;
		cout<<" "<<endl;
		
		cout<<"Precio:"<<e*38<<"$"<<endl;
		cout<<" "<<endl;
		
		cout<<"distancia:"<<"1,300km"<<endl;
		cout<<" "<<endl;
		}
	//si eligieron la opcion 2 del menu principal
	if(a==2){
		//ingrese los datos que se le piden
		cout<<"\nNombre:\n"<<endl;//nombre del cliente
		cin>>cliente1.nombre;
		
		cout<<"\nApellido:\n"<<endl;//apellido del cliente
		cin>>cliente1.Apellido;
		
		cout<<"\nDUI:\n"<<endl;//DUE del cliente
		cin>>cliente1.DUI;
		
		cout<<"\nLicencia:\n"<<endl;//licencia del cliente
		cin>>cliente1.licencia;
		sy();
		cl();
	}	
	
	//opcion 3 del menu principal 
	else {
		//ingrese los datos que se le piden acntinuacion 
		cout<<"\nA�o: \n"<<endl;cin>>A;//a�o del vehiculo

		cout<<"\nNombre: \n"<<endl;cin>>Nombre;//nombre del Vehiculo
		
		cout<<"\ntiempo maximo:\n"<<endl;cin>>Tiempo;//tiempo de uso del vehiculo
		
		cout<<"\ndistancia: \n"<<endl;cin>>Distancia;//distancia recorrida por el vehiculo
		
		cout<<"\ncosto: \n"<<endl;cin>>Costo;//costo del vehiculo
		sy();
		cl();
	}
	}

void cl(){//para limpiar el sistema
	system("cls");
}
void sy(){//fin dela funcion
	system("pause");
}

