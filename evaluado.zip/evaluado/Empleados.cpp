//Programa creado por: Julio Armando Miranda Reyes
//Carnet: MR18031

#include <iostream> //entrada y salida de datos
#include <cstdlib>

using namespace std;

struct Empleados //creando la estructura de cada empleado
{
	char cod[5];
	string nombre;
	int edad;
	float SB;
	float SL;
	float ISSS;
	float AFP;
	float Renta;
	float TP;			
};

float calAFP(float S); // calculando el AFP
float calRenta(float S, float ISSS, float AFP); //calculando la Renta
float calISSS(float S); // calculando el ISSS
int cl(int clear); //verificando que el ingreso sea correcto al problema

int main() //estructura del codigo
{
	int n;
	
	do{	
	cout<<"Cuantos empleados tiene?"<<endl;
	cin>>n; //ingresa el numero de empleados que tiene
	
	n=cl(n);
	system("cls");
	}while(n<1);
	Empleados e[n]; //creando un arreglo con el numero de empleados seleccionados 
	
	for(int i=0;i<n ;i++)
	{ //pide llenar todos los campos de la estructura empleados  con (int i=0;i<n ;i++)
		cout<<"Ingrese el nombre del empleado: "<<endl;
		cin>>e[i].nombre;
		cout<<" "<<endl;
		cout<<"Ingrese el codigo del empleado: "<<endl;
		cin>>e[i].cod;
		cout<<" "<<endl;
		do{
		cout<<"Ingrese la edad del empleado: "<<endl;
		cin>>e[i].edad;
		e[i].edad=cl(e[i].edad);
		cout<<" "<<endl;
		} while(e[i].edad < 1);
		
		do{
		cout<<"Ingrese el salario base del empleado: "<<endl;
		cin>>e[i].SB;
		e[i].SB=cl(e[i].SB);
		cout<<" "<<endl;
		} while(e[i].SB < 1);
		
		e[i].ISSS=calISSS(e[i].SB);
		e[i].AFP=calAFP(e[i].SB);
		e[i].Renta=calRenta(e[i].SB,e[i].ISSS,e[i].AFP);		
		
		int pres; //calcula el totol de cada prestamo
		float totpres = 0; //es la sumatoria de todos los prestamos
		float contador = 0; 
		int cp;
		
		do{
		cout << "La cantidad de prestamos del empleado: "<<endl;
		cin>>cp; //ingresa cuantos prestamos hay
		cp=cl(cp);
		cout<<" "<<endl;
		}while(cp>4 || cp<0);
		
		while(contador+1<=cp)
		{//recorre el ciclo por cada prestamo
			
			do{
			cout<<"Ingrese el monto del prestamo: "<<endl;
			cin>>pres;
			cout<<" "<<endl;
			} while(pres<1);
			
			if(e[i].SB*0.2>totpres)
			{ //evita que el prestamo pase del 20% del sueldo
			totpres+=pres;
			}
			else
			{
				cout<<"El prestamo excede su maximo del 20% de su salario. Su prestamo sera rechazado"<<endl;
				cout<<" "<<endl;
			}
		contador++;
		}
		e[i].TP=totpres; 
		//asigna el total a pagar por los prestamos
		
		e[i].SL=e[i].SB-(e[i].ISSS + e[i].AFP + e[i].Renta + e[i].TP);			
		//calcula el salario liquido del trabajador
	system("cls");
	}
	
	for(int i=0; i<n ;i++)
	{//muestra todos los datos ingresados por el usuario
		cout<<"Nombre del Empleado: "<<e[i].nombre<<endl;
		cout<<" "<<endl;
		cout<<"Codigo del Empleado: "<<e[i].cod<<endl;
		cout<<" "<<endl;
		cout<<"Edad del Empleado: "<<e[i].edad<<endl;
		cout<<" "<<endl;
		cout<<"Salario base del Empleado: "<<e[i].SB<<endl;
		cout<<" "<<endl;
		cout<<"ISSS del Empleado: "<<e[i].ISSS<<endl;
		cout<<" "<<endl;
		cout<<"AFP del Empleado: "<<e[i].AFP<<endl;
		cout<<" "<<endl;
		cout<<"Renta del Empleado: "<<e[i].Renta<<endl;
		cout<<" "<<endl;
		cout<<"Prestamos del Empleado: "<<e[i].TP<<endl;
		cout<<" "<<endl;
		cout<<"Salario liquido del Empleado: "<<e[i].SL<<endl<<endl;
		cout<<" "<<endl;
	}
}

float calISSS(float S)
{
	float ISSS;
	if(S>=600)
	{
		ISSS=30;
	}
	else
	{
		ISSS=S*0.03; //se descuenta el 3% al sueldo	
	}
	
	return ISSS;
}

float calAFP(float S)
{
	float AFP;
	AFP=S*0.0725;//se le descuenta un 7.25%
	return AFP;
}

float calRenta(float S, float ISSS, float AFP)
{
	float Renta;
	float Rsobre;
	float lim;
	
	lim=S-(ISSS+AFP);
	
	if(lim<=472)
	{
		Renta = 0;
	}
	else if(lim<=895.24)
	{
		Rsobre=lim-472;
		Renta=(Rsobre*0.10)+17.67;
	}
	else if(lim<=2038.10)
	{
		Rsobre=lim-895.24;
		Renta=(Rsobre*0.20)+60;
	}
	else if(lim>2038.10)
	{
		Rsobre=lim-2038.10;
		Renta=(Rsobre*0.30)+288.57;
	}
	return Renta;
}

int cl(int clear)//verificando si un dato erroneo fue ingresado y lo corrige
{
	if(cin.fail())//si al ingresar los datos causo error entra al ciclo
    	{
			cin.clear();// limpia la variable
        	cin.ignore();// borra espacios y caracteres
        	cout<<"Ingrese un numero valido."<<endl;
        	system("pause"); // pausa el programa hasta que el usuario desee
        	
			clear=-1; 
			/*asigna el valor de clear a -1, de esa forma los ciclos se repiten
        			si clear entra al if*/
    	}
    return clear;//retorna la variable ya revisada y/o corregida
}
